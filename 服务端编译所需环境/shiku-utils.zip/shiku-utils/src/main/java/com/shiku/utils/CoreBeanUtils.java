package com.shiku.utils;

import com.shiku.commons.thread.RedisCRUD;
import com.shiku.commons.thread.pool.LocalSpringBeanRunnable;
import com.shiku.commons.thread.pool.PersistentRunnable;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
* @Description: TODO(单例类获取   工具类)
* @author lidaye
* @date 2018年7月21日
*/

@Component
public class CoreBeanUtils implements ApplicationContextAware {

    private static ApplicationContext ctx;
    private static LocalSpringBeanRunnable localSpringBeanManager;

    public static LocalSpringBeanRunnable getLocalSpringBeanManager() {
        return localSpringBeanManager;
    }
    @Override
    public void setApplicationContext(ApplicationContext arg0)throws BeansException {
        ctx = arg0;
        localSpringBeanManager=ctx.getBean(LocalSpringBeanRunnable.class);
    }

    public static Object getBean(String beanName) {
        if(ctx == null){
            throw new NullPointerException();
        }
        return ctx.getBean(beanName);
    }
	public static <T> T getBean(Class<T> tClass) {
		if(ctx == null){
			throw new NullPointerException();
		}
		return ctx.getBean(tClass);
	}

    public static PersistentRunnable getPersistent() {
        return getLocalSpringBeanManager().getPersistent();
    }
    public static RedisCRUD getRedisCRUD() {
        return getLocalSpringBeanManager().getRedisCRUD();
    }
}

