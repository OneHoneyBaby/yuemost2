package com.shiku.utils;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

public class ReqUtil {

	private static final String name = "LOGIN_USER_ID";

	private static final String LangName = "REQUEST_LANGEUAGE";

	public static void setLoginedUserId(int userId) {
		RequestContextHolder.getRequestAttributes().setAttribute(name, userId, RequestAttributes.SCOPE_REQUEST);
	}

}
