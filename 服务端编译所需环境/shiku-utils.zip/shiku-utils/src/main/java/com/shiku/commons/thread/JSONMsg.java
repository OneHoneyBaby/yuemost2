package com.shiku.commons.thread;

import com.alibaba.fastjson.JSONObject;


public class JSONMsg extends JSONObject {
	private static final long serialVersionUID = 1L;

	public static JSONMsg success(Object data) {
		return new JSONMsg(1,null, data);
	}

	public static JSONMsg failure(String resultMsg) {
		return new JSONMsg(0, resultMsg, null);
	}

	public static JSONMsg failure(int code, String resultMsg) {
		return new JSONMsg(code, resultMsg, null);
	}

	public JSONMsg(){}

	public JSONMsg(int resultCode, String resultMsg, Object data) {
		put("resultCode", resultCode);
		put("resultMsg", resultMsg);
		put("data", data);
	}
}